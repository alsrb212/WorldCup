package views;

import java.util.ArrayList;
import java.util.Random;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import util.ImageData;

public class ChoiceController extends MasterController {
	ArrayList<Image> SnackImgs = new ArrayList<Image>();
	ArrayList<Image> SnackImgsA = new ArrayList<Image>();
	ArrayList<Image> SnackImgsB = new ArrayList<Image>();
	ArrayList<Image> SnackImgsC = new ArrayList<Image>();
	ArrayList<Image> SnackImgsD = new ArrayList<Image>();

	@FXML
	ImageView imgView;

	@FXML
	ImageView imgview2;

	int imgNum1;
	int imgNum2;

	int status = 1;

	@Override
	public void init() {
		ImageData imageData = new ImageData(SnackImgs);
		rnd(SnackImgs);
	}

	public void rnd(ArrayList<Image> snack) {
		int save = snack.size() + 1;
		Random rnd = new Random();
		int rndimg1;
		int rndimg2;
		while (true) {
			rndimg1 = rnd.nextInt(save);
			if (snack.get(rndimg1) != null) {
				break;
			}
		}
		while(true) {
			rndimg2 = rnd.nextInt(save);
			if(snack.get(rndimg2) != null && snack.get(rndimg2) != snack.get(rndimg1)) {
				break;
			}
		}
		imgView.setImage(snack.get(rndimg1));
		imgview2.setImage(snack.get(rndimg2));
		imgNum1 = rndimg1;
		imgNum2 = rndimg2;
	}

	public void clickImg() {
		if (status == 1) {
			SnackImgsA.add(SnackImgs.get(imgNum1));
			SnackImgs.remove(imgNum1);
			SnackImgs.remove(imgNum2);
			rnd(SnackImgs);
			System.out.println("1");
		} else if (status == 2) {
			SnackImgsB.add(SnackImgs.get(imgNum1));
			SnackImgsA.remove(imgNum1);
			SnackImgsA.remove(imgNum2);
			rnd(SnackImgsB);
		} else if (status == 3) {
			SnackImgsC.add(SnackImgs.get(imgNum1));
			SnackImgsB.remove(imgNum1);
			SnackImgsB.remove(imgNum2);
			rnd(SnackImgsC);
		} else if (status == 4) {
			SnackImgsD.add(SnackImgs.get(imgNum1));
			SnackImgsC.remove(imgNum1);
			SnackImgsC.remove(imgNum2);
			rnd(SnackImgsD);
		} else if (status == 5) {
//			imgNum1 얘가 우승
		}
	}

	public void clickImg2() {
		if (status == 1) {
			SnackImgsA.add(SnackImgs.get(imgNum2));
			SnackImgs.remove(imgNum1);
			SnackImgs.remove(imgNum2);
			rnd(SnackImgs);
		} else if (status == 2) {
			SnackImgsB.add(SnackImgs.get(imgNum2));
			SnackImgsA.remove(imgNum1);
			SnackImgsA.remove(imgNum2);
			rnd(SnackImgsB);
		} else if (status == 3) {
			SnackImgsC.add(SnackImgs.get(imgNum2));
			SnackImgsB.remove(imgNum1);
			SnackImgsB.remove(imgNum2);
			rnd(SnackImgsC);
		} else if (status == 4) {
			SnackImgsD.add(SnackImgs.get(imgNum2));
			SnackImgsC.remove(imgNum1);
			SnackImgsC.remove(imgNum2);
			rnd(SnackImgsD);
		} else if (status == 5) {
//			imgNum1 얘가 우승
		}
	}

}