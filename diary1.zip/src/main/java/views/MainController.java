package views;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import domain.UserVO;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import main.MainApp;
import util.JDBCutil;
import util.Util;

public class MainController extends MasterController {
	@FXML
	private Button btnPrev;
	@FXML
	private Button btnNext;

	@FXML
	private Label loginInfo;

	@FXML
	private GridPane gridCalendar;

	private UserVO user;

	public UserVO getUser() {
		return user;
	}

	public void setLoginInfo(UserVO vo) {
		this.user = vo;
		loginInfo.setText(vo.getName() + "[" + vo.getId() + "]");
	}

	public void logout() {
		user = null;
		MainApp.app.loadPage("login");
	}

	@Override
	public void init() {

	}

	public void Choicepage() {
		MainApp.app.loadPage("choice");
	}
}
