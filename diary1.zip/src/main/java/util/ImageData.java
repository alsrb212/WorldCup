package util;

import java.util.ArrayList;

import javafx.scene.image.Image;

public class ImageData {
	public ImageData(ArrayList<Image> SnackImgs) {
		for(int i = 1; i < 80; i++) {
			String url = getClass().getResource("/cookie/" + i + ".jpg").toString();
			Image img = new Image(url);
			SnackImgs.add(img);
		}
		
	}
	
}
